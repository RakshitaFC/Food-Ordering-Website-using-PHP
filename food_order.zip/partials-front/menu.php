<?php include('config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Website</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <section class="navbar">
        <div class="container">
            <div class="logo">
                <a href="#" title="Logo">
                    <img src="images/logo.png" alt="Restaurant Logo" class="img-responsive" width="30px" height="70px">
                </a>
            </div>

            <div class="menu text-right">
                <ul>
                    <li>
                        <a href="<?php echo SITEURL; ?>" style="font-size: 25px;  text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF;">Home</a>
                    </li>
                    <li>
                        <a href="<?php echo SITEURL; ?>categories.php" style="font-size: 25px; text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF;">Categories</a>
                    </li>
                    <li>
                        <a href="<?php echo SITEURL; ?>foods.php" style="font-size: 25px; text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF;">Foods</a>
                    </li>
                    <li>
                        <a href="<?php echo SITEURL; ?>contact.php" style="font-size: 25px; text-shadow: 0 0 3px #FF0000, 0 0 5px #0000FF;">Contact</a>
                    </li>
                </ul>
            </div>

            <div class="clearfix"></div>
        </div>
    </section>
   