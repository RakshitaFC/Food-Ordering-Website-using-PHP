<?php include('partials-front/menu.php'); ?>
<hr style="width:100%; text-align:left; margin-left:0">
<head>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<style>
*{box-sizing:border-box;}
body{font-family: 'Open Sans', sans-serif; color:#333; font-size:14px; background-color:#dadada; padding:100px;}
.form_box{width:400px; padding:10px; background-color:white;}

input{padding:5px;  margin-bottom:5px;}
input[type="submit"]{border:none; outlin:none; background-color:#679f1b; color:white;}
.heading{background-color:#ac1219; color:white; height:40px; width:100%; line-height:40px; text-align:center;}
.shadow{
  -webkit-box-shadow: 0px 0px 17px 1px rgba(0,0,0,0.43);
-moz-box-shadow: 0px 0px 17px 1px rgba(0,0,0,0.43);
box-shadow: 0px 0px 17px 1px rgba(0,0,0,0.43);}
.pic{text-align:left; width:33%; float:left;}
</style>
<head>
<body>
    <?php 
        if(isset($_SESSION['order']))
        {
            echo $_SESSION['order'];
            unset($_SESSION['order']);
        }
    ?>
 <section class="categories" style="background-image:url(images/bg1.jpg); background-repeat:no-repeat;">
 <div class = "container">
 <div class="form_box shadow" >
 <form method="post" action="feedback-save.php">
 <div class="heading">
   Please leave your feedback
 </div>
 <br/>
 <p>What do you think about the quality of our service?</p>
 <div>
   <div class="pic">
     <img src="images/bad.png" alt="" width="110px" heigth="110px"> <br/>
     <input type="radio" name="quality" value="0"> Bad
   </div>
   <div class="pic">
     <img src="images/neutral.png" alt="" width="110px" heigth="110px"> <br/>
     <input type="radio" name="quality" value="1"> Okay
   </div>
   <div class="pic">
     <img src="images/good.png" alt="" width="110px" heigth="110px"> <br/>
     <input type="radio" name="quality" value="2"> Good
   </div>
 </div>
  <div>
 <div><p>Do you have any suggestion for us? </p></div><textarea name=" suggestion" rows="8" cols="40"></textarea>
 </div>
  <div> 
 <input type="submit" name="submit" value="Submit Form">
  </div>
</form>
 </div>
</div>
</section>
</body>
<hr style="width:100%; text-align:left; margin-left:0">
<?php include('partials-front/footer.php'); ?>