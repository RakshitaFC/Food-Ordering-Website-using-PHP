<?php 
include('partials/menu.php')
?>
<div class="main-content">
	<div class="wrapper">
		<h1>Customer Feedback</h1>
		<h4>(Quality score:  0-Bad   1-Okay   2-Good)</h4>
		<br/><br/>
		<table class="tbl-full">
				<tr>
					<th>Sr no.</th>
					<th>Quality score( 0 / 1 / 2 )</th>
					<th>Feedback description</th>
			
				</tr>
				<?php
				$sql = "SELECT * FROM feedback";
				$res = mysqli_query($conn,$sql);
				if($res==TRUE) 
				{
					$count = mysqli_num_rows($res);
					$sn=1;
					if($count>0)
					{while($rows=mysqli_fetch_assoc($res))
						{
							$id=$rows['id'];
							$rating=$rows['quality_score'];
							$feedback=$rows['feedback'];
						?>
				<tr>
					<td><?php echo $sn++ ?></td>
					<td><?php echo $rating ?></td>
					<td><?php echo $feedback ?></td>
					
				</tr>
						<?php
	
						}
					}
				}



				?>
				
			</table>
		
	</div>
</div>

<?php 
include('partials/footer.php')
?>