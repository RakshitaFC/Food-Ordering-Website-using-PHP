<?php 
include('partials/menu.php')
?>

<!--Main section starts here-->
<div class="main-content">
	<div class="wrapper">
		<h1>Manage Admin</h1>
		<br/><br/>


		<?php
			if(isset($_SESSION['add']))//Checking if Session is set or not
			{
				echo $_SESSION['add'];//Display session message if set
				unset($_SESSION['add']);//Removing session message
			} 
			if(isset($_SESSION['delete']))//Checking if Session is set or not
			{
				echo $_SESSION['delete'];//Display session message if set
				unset($_SESSION['delete']);//Removing session message
			} 
			if(isset($_SESSION['update']))//Checking if Session is set or not
			{
				echo $_SESSION['update'];//Display session message if set
				unset($_SESSION['update']);//Removing session message
			} 
			
			if(isset($_SESSION['user-not-found']))//Checking if Session is set or not
			{
				echo $_SESSION['user-not-found'];//Display session message if set
				unset($_SESSION['user-not-found']);//Removing session message
			} 
			
			if(isset($_SESSION['pwd-not-match']))//Checking if Session is set or not
			{
				echo $_SESSION['pwd-not-match'];//Display session message if set
				unset($_SESSION['pwd-not-match']);//Removing session message
			}
			if(isset($_SESSION['change-pwd']))//Checking if Session is set or not
			{
				echo $_SESSION['change-pwd'];//Display session message if set
				unset($_SESSION['change-pwd']);//Removing session message
			}
		?>
<!-- Button to add admin -->

			<br/><br/s><a href="add-admin.php" class="btn-primary">Add admin</a><br/><br/><br/><br/>
			<table class="tbl-full">
				<tr>
					<th>Sr no.</th>
					<th>Full name</th>
					<th>Username</th>
					<th>Action</th>
				</tr>
				<?php
				$sql = "SELECT * FROM tbl_admin";
				$res = mysqli_query($conn,$sql);
				if($res==TRUE) 
				{
					$count = mysqli_num_rows($res);
					$sn=1;
					if($count>0)
					{while($rows=mysqli_fetch_assoc($res))
						{
							$id=$rows['id'];
							$full_name=$rows['full_name'];
							$username=$rows['username'];
						?>
				<tr>
					<td><?php echo $sn++ ?></td>
					<td><?php echo $full_name ?></td>
					<td><?php echo $username ?></td>
					<td>
						<a href="<?php echo SITEURL?>/admin/update-password.php?id=<?php echo $id; ?>" class="btn-primary">Change password</a>
						<a href="<?php echo SITEURL?>/admin/update-admin.php?id=<?php echo $id; ?>" class="btn-secondary">Update admin</a>
						<a href="<?php echo SITEURL?>/admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-danger">Delete admin</a>
					</td>
				</tr>
						<?php
	
						}
					}
				}



				?>
				
			</table>
		
	</div>
</div>
<!--Main section ends here-->

<?php 
include('partials/footer.php')
?>