<?php 

include("../config/constants.php");

$id = $_GET['id'];

$sql = "DELETE FROM tbl_admin  where id=$id";

$res = mysqli_query($conn,$sql);
if($res == TRUE)
{
$_SESSION['delete']= "<div class='success'>Admin deleted successfully</div>";
header('location:'.SITEURL.'admin/manage-admin.php');
}
else
{
$_SESSION['delete']= "<div class='error'>Admin not deleted successfully..Try again later!!</div>";
header('location:'.SITEURL.'admin/manage-admin.php');
}

?>
