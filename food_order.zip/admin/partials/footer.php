<!--footer section starts here-->
<div class="footer">
	<div class="wrapper">
		<p class="text-center">
			FY MSc 2021-22 Sem1 Project .
			Developed by : Rakshita,Snehal,Neha,Vikas
		</p>
	</div>
</div>
<!--footer section ends here-->

</body>
</html>