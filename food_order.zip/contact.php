
<?php include('partials-front/menu.php'); ?>
<section class="food-search" style="background-image: url(images/bg1.jpg); background-size:1800px 2000px">
<div class="container">
<h1 style="color:white; font-size=800px;">Contact us!! Social media handles given below</h1>
<h1 style="color:white; font-size=800px;">We love hearing from you!!!!</h1>
<h1 style="color:white; font-size=800px;">Email us at : <a href="#">*********emailid********</a></h1>
</div>
</section>
<?php include('partials-front/footer.php'); ?>